/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Maximize, Minimize, Download } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { toPng } from 'html-to-image';
import { ProxyImage } from './components/ProxyImage';
import { Slide1, Slide2, Slide3, Slide4, Slide5, Slide6, Slide7, Slide8, Slide9, Slide10, Slide11, Slide12 } from './components/Slides';
const proxyImage = (url: string) => `https://wsrv.nl/?url=${encodeURIComponent(url)}`;
const logoHorizontal = proxyImage('https://leydux.com.br/wp-content/uploads/2026/03/linkar-horizontal.svg');

const slides = [Slide1, Slide2, Slide3, Slide4, Slide5, Slide6, Slide7, Slide8, Slide9, Slide10, Slide11, Slide12];

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const downloadSlide = async () => {
    if (!containerRef.current) return;
    
    setIsDownloading(true);
    
    // Pequeno delay para garantir que o estado de isDownloading refletiu no DOM (escondendo botões)
    setTimeout(async () => {
      try {
        const node = containerRef.current;
        if (!node) return;

        const dataUrl = await toPng(node, {
          pixelRatio: 2,
          cacheBust: true,
          imagePlaceholder: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=',
          filter: (element) => {
            const exclusionClasses = ['download-exclude', 'controls-overlay'];
            if (element instanceof HTMLElement) {
              if (element.tagName === 'BUTTON' || exclusionClasses.some(cls => element.classList.contains(cls)) || element.id === 'controls-overlay') {
                return false;
              }
            }
            return true;
          }
        });
        
        const link = document.createElement('a');
        link.download = `Linkar-Academy-Slide-${currentSlide + 1}.png`;
        link.href = dataUrl;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (err) {
        console.error('Erro ao baixar slide:', err);
        alert('Erro ao baixar o slide. Verifique o console para mais detalhes.');
      } finally {
        setIsDownloading(false);
      }
    }, 500);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? prev : prev + 1));
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? prev : prev - 1));
  };

  const toggleFullscreen = async () => {
    const element = containerRef.current;
    if (!element) return;

    if (!document.fullscreenElement) {
      try {
        if (element.requestFullscreen) {
          await element.requestFullscreen();
        } else if ((element as any).webkitRequestFullscreen) {
          await (element as any).webkitRequestFullscreen();
        } else if ((element as any).mozRequestFullScreen) {
          await (element as any).mozRequestFullScreen();
        } else if ((element as any).msRequestFullscreen) {
          await (element as any).msRequestFullscreen();
        }
      } catch (err) {
        console.error("Error attempting to enable fullscreen:", err);
      }
    } else {
      try {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if ((document as any).webkitExitFullscreen) {
          await (document as any).webkitExitFullscreen();
        } else if ((document as any).mozCancelFullScreen) {
          await (document as any).mozCancelFullScreen();
        } else if ((document as any).msExitFullscreen) {
          await (document as any).msExitFullscreen();
        }
      } catch (err) {
        console.error("Error attempting to exit fullscreen:", err);
      }
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Space') {
        nextSlide();
      } else if (e.key === 'ArrowLeft') {
        prevSlide();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const CurrentSlideComponent = slides[currentSlide];
  const isFirstSlide = currentSlide === 0;
  const isLastSlide = currentSlide === slides.length - 1;

  return (
    <div className="min-h-screen bg-neutral-900 flex items-center justify-center p-0 md:p-4">
      <div 
        id="slide-container"
        ref={containerRef}
        className={`relative shadow-2xl overflow-hidden flex flex-col transition-colors duration-700 ${isFirstSlide ? 'bg-brand-blue' : 'bg-white'}`}
        style={{
          width: '100%',
          maxWidth: isFullscreen ? '100%' : '1920px',
          aspectRatio: isFullscreen ? 'auto' : '16/9',
          height: isFullscreen ? '100vh' : 'auto',
          maxHeight: isFullscreen ? '100vh' : 'calc(100vh - 2rem)',
        }}
      >
        {/* Safe Margin Container */}
        <div className="absolute inset-0 p-12 md:p-20 lg:p-24 flex flex-col">
          {/* Logo overlay */}
          <AnimatePresence>
            {!isFirstSlide && !isLastSlide && currentSlide !== 10 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute top-12 md:top-16 left-0 right-0 flex justify-center z-50 pointer-events-none"
              >
                <ProxyImage
                  src={logoHorizontal}
                  alt="Linkar Academy"
                  className="h-8 md:h-10 w-auto"
                  referrerPolicy="no-referrer"
                  crossOrigin="anonymous"
                />
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
              className="flex-1 w-full h-full"
            >
              <CurrentSlideComponent />
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Controls Overlay */}
        {!isDownloading && (
          <div id="controls-overlay" className="absolute bottom-6 left-0 right-0 flex justify-between items-center px-8 z-50 opacity-30 hover:opacity-100 transition-opacity duration-300">
            <div className={`font-sans text-sm font-medium ${isFirstSlide ? 'text-white/50' : 'text-brand-blue/50'}`}>
              {currentSlide + 1} / {slides.length}
            </div>
            
            <div className={`flex items-center space-x-4 backdrop-blur-sm px-4 py-2 rounded-full shadow-sm border transition-colors ${isFirstSlide ? 'bg-brand-blue/50 border-white/10' : 'bg-white/80 border-brand-blue/10'}`}>
              <button 
                onClick={prevSlide} 
                disabled={currentSlide === 0}
                className={`p-2 disabled:opacity-30 transition-colors ${isFirstSlide ? 'text-white hover:text-brand-gold' : 'text-brand-blue hover:text-brand-gold'}`}
              >
                <ChevronLeft size={24} />
              </button>
              <button 
                onClick={nextSlide} 
                disabled={currentSlide === slides.length - 1}
                className={`p-2 disabled:opacity-30 transition-colors ${isFirstSlide ? 'text-white hover:text-brand-gold' : 'text-brand-blue hover:text-brand-gold'}`}
              >
                <ChevronRight size={24} />
              </button>
              <div className={`w-px h-6 mx-2 ${isFirstSlide ? 'bg-white/20' : 'bg-brand-blue/20'}`}></div>
              <button 
                onClick={downloadSlide} 
                className="p-3 rounded-full bg-black/10 hover:bg-black/20 backdrop-blur-md transition-all text-current"
                title="Baixar Slide (1920x1080)"
              >
                <Download size={24} />
              </button>
              <button 
                onClick={toggleFullscreen}
                className={`p-2 transition-colors ${isFirstSlide ? 'text-white hover:text-brand-gold' : 'text-brand-blue hover:text-brand-gold'}`}
                title="Tela Cheia (F)"
              >
                {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
