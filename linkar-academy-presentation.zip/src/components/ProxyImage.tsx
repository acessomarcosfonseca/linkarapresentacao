import React, { useState, useEffect } from 'react';

interface ProxyImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
}

export const ProxyImage: React.FC<ProxyImageProps> = ({ src, ...props }) => {
  const [dataUrl, setDataUrl] = useState<string>(src);

  useEffect(() => {
    let isMounted = true;
    
    if (src && !src.startsWith('data:')) {
      fetch(src, { mode: 'cors' })
        .then(res => res.blob())
        .then(blob => {
          const reader = new FileReader();
          reader.onloadend = () => {
            if (isMounted && reader.result) {
              setDataUrl(reader.result as string);
            }
          };
          reader.readAsDataURL(blob);
        })
        .catch(err => {
          console.error('Failed to convert image to base64:', src, err);
          if (isMounted) setDataUrl(src);
        });
    } else {
      setDataUrl(src);
    }

    return () => {
      isMounted = false;
    };
  }, [src]);

  return <img src={dataUrl} {...props} />;
};
