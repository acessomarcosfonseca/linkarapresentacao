import React from 'react';
import { motion } from 'motion/react';
import { Target, Compass, Eye } from 'lucide-react';
import { ProxyImage } from './ProxyImage';
const proxyImage = (url: string) => `https://wsrv.nl/?url=${encodeURIComponent(url)}`;
const logoHorizontal = proxyImage('https://leydux.com.br/wp-content/uploads/2026/03/linkar-horizontal.svg');
const logoWhite = proxyImage('https://leydux.com.br/wp-content/uploads/2026/03/linkar-academy-3.svg');
import logoSummit from '../assets/logo-summit.svg';

export const Slide1 = () => (
  <div className="flex flex-col items-center justify-center h-full w-full text-center">
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="w-full max-w-sm mb-12 h-auto"
    >
      <ProxyImage 
        src={logoWhite} 
        alt="Linkar Academy" 
        className="w-full h-auto"
        crossOrigin="anonymous"
      />
    </motion.div>
    <motion.p 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.4 }}
      className="text-base md:text-lg font-light tracking-widest text-white/80 max-w-2xl"
    >
      Programa de Formação Interdisciplinar em Marketing para Organizações e Negócios
    </motion.p>
  </div>
);

export const Slide2 = () => (
  <div className="flex flex-col justify-center h-full max-w-5xl mx-auto">
    <motion.h2 
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="text-5xl font-serif text-brand-gold mb-12"
    >
      Origem do Programa
    </motion.h2>
    <div className="space-y-6 text-lg md:text-xl leading-relaxed text-brand-blue/90">
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
        O Linkar Academy nasce da percepção de um cenário recorrente no mercado contemporâneo: embora o marketing tenha se tornado uma das áreas mais estratégicas para o crescimento de empresas e marcas, ainda existe um desalinhamento significativo entre a formação dos profissionais da área e a compreensão do marketing por parte de empresários e gestores.
      </motion.p>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
        De um lado, profissionais em formação ou em início de carreira buscam desenvolver competências técnicas e estratégicas para atuar no mercado. De outro, empresários e tomadores de decisão lidam diariamente com demandas relacionadas a marketing, comunicação, posicionamento e presença digital, muitas vezes sem uma compreensão clara do papel, das possibilidades e dos limites dessas disciplinas dentro do contexto empresarial.
      </motion.p>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}>
        Esse descompasso frequentemente gera ruídos, expectativas desalinhadas e decisões pouco estruturadas, impactando tanto a qualidade das entregas quanto a efetividade das estratégias adotadas. É nesse contexto que surge o Linkar Academy.
      </motion.p>
    </div>
  </div>
);

export const Slide3 = () => (
  <div className="flex flex-col justify-center h-full max-w-5xl mx-auto">
    <motion.h2 
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="text-5xl font-serif text-brand-gold mb-12"
    >
      Sobre o Linkar Academy
    </motion.h2>
    <div className="space-y-6 text-lg md:text-xl leading-relaxed text-brand-blue/90">
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
        O Linkar Academy nasce da percepção de um cenário recorrente no mercado contemporâneo: embora o marketing tenha se tornado uma das áreas mais estratégicas para o crescimento de empresas e marcas, ainda existe um desalinhamento significativo entre a formação dos profissionais da área e a compreensão do marketing por parte de empresários e gestores.
      </motion.p>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
        De um lado, profissionais em formação ou em início de carreira buscam desenvolver competências técnicas e estratégicas para atuar no mercado. De outro, empresários e tomadores de decisão lidam diariamente com demandas relacionadas a marketing, comunicação, posicionamento e presença digital, muitas vezes sem uma compreensão clara do papel, das possibilidades e dos limites dessas disciplinas dentro do contexto empresarial.
      </motion.p>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}>
        Esse descompasso frequentemente gera ruídos, expectativas desalinhadas e decisões pouco estruturadas, impactando tanto a qualidade das entregas quanto a efetividade das estratégias adotadas. É nesse contexto que surge o Linkar Academy.
      </motion.p>
    </div>
  </div>
);

export const Slide4 = () => {
  const valores = [
    { title: "Excelência", desc: "compromisso com alto padrão de qualidade na geração e aplicação do conhecimento." },
    { title: "Clareza", desc: "comunicação transparente e visão estratégica nas relações entre profissionais e empresas." },
    { title: "Conexão", desc: "estímulo ao diálogo e à integração do ecossistema de marketing e negócios." },
    { title: "Consistência", desc: "desenvolvimento baseado em experiência prática e visão de mercado." },
    { title: "Evolução contínua", desc: "incentivo ao aprendizado constante e adaptação às mudanças do mercado." },
    { title: "Responsabilidade profissional", desc: "atuação ética e orientada a resultados sustentáveis." }
  ];

  return (
    <div className="flex flex-col justify-center h-full max-w-7xl mx-auto w-full px-4 py-6">
      <div className="flex flex-col gap-6 h-full">
        
        {/* Top Row: Missão & Valores */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1">
          
          {/* Missão */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="lg:col-span-5 bg-white p-8 rounded-3xl border border-brand-blue/5 shadow-xl shadow-brand-blue/5 flex flex-col justify-center relative overflow-hidden group"
          >
            <div className="absolute top-0 left-0 w-1.5 h-full bg-brand-gold"></div>
            <h3 className="text-2xl font-serif text-brand-gold mb-4 flex items-center gap-3">
              <Target className="w-6 h-6" /> Missão
            </h3>
            <div className="text-brand-blue/70 text-[13px] leading-relaxed space-y-3">
              <p>O Linkar Academy nasce da percepção de um cenário recorrente no mercado contemporâneo: embora o marketing tenha se tornado uma das áreas mais estratégicas para o crescimento de empresas e marcas, ainda existe um desalinhamento significativo entre a formação dos profissionais da área e a compreensão do marketing por parte de empresários e gestores.</p>
              <p>De um lado, profissionais em formação ou em início de carreira buscam desenvolver competências técnicas e estratégicas para atuar no mercado. De outro, empresários e tomadores de decisão lidam diariamente com demandas relacionadas a marketing, comunicação, posicionamento e presença digital, muitas vezes sem uma compreensão clara do papel, das possibilidades e dos limites dessas disciplinas dentro do contexto empresarial.</p>
              <p>Esse descompasso frequentemente gera ruídos, expectativas desalinhadas e decisões pouco estruturadas, impactando tanto a qualidade das entregas quanto a efetividade das estratégias adotadas. É nesse contexto que surge o Linkar Academy.</p>
            </div>
          </motion.div>

          {/* Valores */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}
            className="lg:col-span-7 bg-white p-8 lg:p-10 rounded-3xl border border-brand-blue/5 shadow-xl shadow-brand-blue/5 flex flex-col justify-center"
          >
            <h3 className="text-2xl font-serif text-brand-gold mb-8 flex items-center gap-3">
              <Compass className="w-6 h-6" /> Valores
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-6">
              {valores.map((valor, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 + (idx * 0.1) }}
                  className="flex flex-col gap-2"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-brand-gold/10 flex items-center justify-center text-brand-gold font-bold text-sm shrink-0">
                      {idx + 1}
                    </div>
                    <h4 className="font-semibold text-brand-blue text-base">{valor.title}</h4>
                  </div>
                  <p className="text-brand-blue/60 text-[13px] leading-relaxed pl-11">{valor.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

        </div>

        {/* Bottom Row: Visão */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="bg-brand-blue p-8 rounded-3xl shadow-xl shadow-brand-blue/10 relative overflow-hidden shrink-0 flex flex-col md:flex-row items-center gap-6 md:gap-10"
        >
          <div className="absolute -right-6 -top-12 text-white/5">
            <Eye className="w-64 h-64" />
          </div>
          <div className="shrink-0 relative z-10 flex items-center justify-center">
            <h3 className="text-3xl font-serif text-brand-gold flex items-center gap-3">
              <Eye className="w-8 h-8" /> Visão
            </h3>
          </div>
          <div className="w-full md:w-px h-px md:h-16 bg-brand-gold/20 relative z-10"></div>
          <div className="text-white/90 text-base md:text-lg leading-relaxed relative z-10 font-light flex-1 text-center md:text-left">
            <p>Transformar a relação entre profissionais e empresas no Brasil, tornando o alinhamento estratégico e a excelência em marketing um novo padrão de mercado.</p>
          </div>
        </motion.div>

      </div>
    </div>
  );
};

export const Slide5 = () => {
  const pilares = [
    { title: "Protagonismo profissional", desc: "Acreditamos em profissionais que assumem responsabilidade sobre sua própria formação, carreira e impacto nas organizações." },
    { title: "Excelência com método", desc: "Resultados consistentes são construídos a partir de padrões, disciplina e compromisso com a qualidade." },
    { title: "Visão de negócio", desc: "Todo profissional precisa compreender o funcionamento das organizações e o impacto de suas decisões no contexto empresarial." },
    { title: "Comunicação estratégica", desc: "A capacidade de comunicar ideias com clareza, propósito e inteligência é essencial para gerar valor dentro das organizações." },
    { title: "Desenvolvimento humano", desc: "A formação profissional precisa caminhar junto com o desenvolvimento de postura, inteligência emocional e maturidade." },
    { title: "Conexão com o mercado", desc: "Aprender significa compreender a realidade das organizações e desenvolver soluções aplicáveis ao mundo dos negócios." }
  ];

  return (
    <div className="flex flex-col justify-center h-full max-w-6xl mx-auto">
      <motion.h2 
        initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
        className="text-5xl font-serif text-brand-gold mb-12 text-center"
      >
        Pilares de Cultura
      </motion.h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {pilares.map((pilar, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: idx * 0.1 }}
            className="flex flex-col"
          >
            <div className="flex items-center mb-3">
              <span className="text-3xl font-serif text-brand-gold mr-4 opacity-50">{idx + 1}.</span>
              <h4 className="text-xl font-semibold text-brand-blue">{pilar.title}</h4>
            </div>
            <p className="text-brand-blue/70 leading-relaxed pl-10">{pilar.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export const Slide6 = () => {
  const areas = [
    { title: "Marketing Estratégico", desc: "Planejamento, análise de mercado e posicionamento." },
    { title: "Comunicação e Narrativa", desc: "Storytelling, oratória e comunicação profissional." },
    { title: "Design e Construção de Marcas", desc: "Branding, identidade visual e percepção de valor." },
    { title: "Produção Audiovisual", desc: "Desenvolvimento de conteúdo e estratégias de comunicação digital." },
    { title: "Vendas e Conversão", desc: "Processos comerciais, relacionamento com clientes e fidelização." },
    { title: "Comportamento Profissional", desc: "Postura corporativa, ética, liderança e saúde comportamental." }
  ];

  return (
    <div className="flex flex-col justify-center h-full max-w-6xl mx-auto">
      <motion.h2 
        initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}
        className="text-5xl font-serif text-brand-gold mb-4 text-center"
      >
        Estrutura Pedagógica 360º
      </motion.h2>
      <motion.p 
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
        className="text-xl text-center text-brand-blue/80 mb-12"
      >
        O programa integra diferentes áreas de conhecimento:
      </motion.p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-10">
        {areas.map((area, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, x: idx % 2 === 0 ? -20 : 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + (idx * 0.1) }}
            className="border-l-2 border-brand-gold pl-6 py-2"
          >
            <h4 className="text-2xl font-serif text-brand-blue mb-2">{area.title}</h4>
            <p className="text-brand-blue/70 text-lg">{area.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export const Slide7 = () => {
  const docentes = [
    { name: "Josuel Ventura", role: "Fundador e Diretor", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Josuel-Ventura.jpeg.jpg") },
    { name: "Cláudia Palermo", role: "Gestão de Relacionamento", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Claudia-Palermo.jpeg.jpg") },
    { name: "Paulo Victor", role: "Coordenador de TI", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Paulo-Victor.jpeg.jpg") },
    { name: "Marcos Fonseca", role: "Arquiteto de Marca e Percepção", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Marcos-Fonseca.jpeg.jpg") },
    { name: "Kênia Roman Triaca", role: "Ética, Saúde e Cultura Empresarial", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Kenia-Roman-Triaca.jpeg.jpg") },
    { name: "Thales Mendes", role: "Canais Digitais, Marketplaces e Automação", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Thales-Mendes.jpeg.jpg") },
    { name: "Júnior Biasoli", role: "Estratégias de Marketing para Indústria e Negócios", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Junior-Biasoli-.jpeg.jpg") },
    { name: "Marília Kanagusto", role: "Direção Visual para Marcas", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Marilia-Kanagusto.jpeg.jpg") },
    { name: "Joelma Ospedal", role: "Comunicação Escrita, Narrativa e Oratória", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Joelma-Ospedal.jpeg.jpg") },
    { name: "Mauricio Buffa", role: "Mentalidade Empreendedora & Visão de Negócios", img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/Mauricio-Buffa.jpeg.jpg") }
  ];

  return (
    <div className="flex flex-col justify-center h-full max-w-7xl mx-auto w-full px-4">
      <motion.h2 
        initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}
        className="text-5xl font-serif text-brand-gold mb-12 text-center"
      >
        Corpo Docente
      </motion.h2>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-x-4 gap-y-8">
        {docentes.map((docente, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: idx * 0.05 }}
            className="flex flex-col items-center text-center group"
          >
            <div className="w-28 h-28 rounded-full overflow-hidden mb-4 border-2 border-brand-gold/30 group-hover:border-brand-gold transition-colors shadow-md">
              <ProxyImage src={docente.img} alt={docente.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" referrerPolicy="no-referrer" crossOrigin="anonymous" />
            </div>
            <h4 className="font-serif text-[15px] text-brand-blue font-semibold leading-tight">{docente.name}</h4>
            <p className="text-[11px] text-brand-blue/70 mt-1.5 leading-snug px-2">{docente.role}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export const Slide8 = () => {
  return (
    <div className="flex flex-col justify-center h-full max-w-5xl mx-auto w-full px-4">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-serif text-brand-gold mb-4">Estrutura de Formação Interdisciplinar</h2>
        <p className="text-brand-blue/70 text-lg">Os dois eixos do programa</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <motion.div 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-white p-10 rounded-2xl border border-brand-blue/10 shadow-xl shadow-brand-blue/5 relative group hover:-translate-y-1 transition-transform duration-300"
        >
          <div className="absolute top-0 left-0 w-full h-2 bg-brand-gold rounded-t-2xl"></div>
          <h3 className="text-3xl font-serif text-brand-blue mb-4 mt-2">Linkar for Makers</h3>
          <p className="text-lg leading-relaxed text-brand-blue/70">
            Eixo voltado a estudantes e profissionais que desejam desenvolver formação interdisciplinar em marketing aplicada à realidade do mercado.
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="bg-white p-10 rounded-2xl border border-brand-blue/10 shadow-xl shadow-brand-blue/5 relative group hover:-translate-y-1 transition-transform duration-300"
        >
          <div className="absolute top-0 left-0 w-full h-2 bg-brand-gold rounded-t-2xl"></div>
          <h3 className="text-3xl font-serif text-brand-blue mb-4 mt-2">Linkar for Businesses</h3>
          <p className="text-lg leading-relaxed text-brand-blue/70">
            Eixo voltado a empresários e gestores que desejam desenvolver uma compreensão mais ampla e estruturada sobre o marketing aplicado aos seus negócios.
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export const Slide9 = () => (
  <div className="flex flex-col justify-center h-full max-w-5xl mx-auto text-center">
    <motion.h2 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-5xl font-serif text-brand-gold mb-12"
    >
      Proposta de Valor Linkar Academy
    </motion.h2>
    <div className="space-y-8 text-2xl leading-relaxed text-brand-blue/90 font-light">
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
        Ao conectar esses dois públicos dentro de uma mesma visão de mercado, o Linkar Academy se posiciona como um interlocutor entre formação profissional e realidade empresarial.
      </motion.p>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
        Essa conexão contribui para elevar o padrão de atuação do marketing no contexto empresarial, reduzir ruídos entre profissionais e empresas e fortalecer relações de trabalho mais claras e estratégicas.
      </motion.p>
    </div>
  </div>
);

export const Slide10 = () => {
  const patentes = [
    { 
      title: "Explorer", 
      badge: "Nível Médio - 1º Mês", 
      desc: "Ingresso no ecossistema Linkar. Etapa de exploração, ambientação e fundamentos iniciais.", 
      img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/01-1.png") 
    },
    { 
      title: "Builder", 
      badge: "Nível Médio - Meses 2 e 3", 
      desc: "Desenvolvimento da base técnica e aplicação orientada dos conhecimentos.", 
      img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/02-1.png") 
    },
    { 
      title: "Operator", 
      badge: "Nível Médio - Meses 4 a 6", 
      desc: "Execução estruturada e atuação prática com acompanhamento.", 
      img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/03-1.png"),
      squad: { 
        name: "Pulse", 
        desc: "Início da atuação prática", 
        xp: "300 XP", 
        nameColor: "text-brand-blue",
        squadColor: "text-gray-400",
        border: "border-gray-200", 
        bg: "bg-gray-50",
        dot: "bg-gray-400",
        xpBg: "bg-gray-100",
        xpText: "text-brand-blue",
        lineColor: "bg-gray-200"
      } 
    },
    { 
      title: "Strategist", 
      badge: "Nível Avançado - 1º Trimestre", 
      desc: "Visão estratégica conectada aos objetivos do negócio.", 
      img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/04-1.png"), 
      isAdvanced: true,
      squad: { 
        name: "Vector", 
        desc: "Atuação com direção estratégica", 
        xp: "600 XP", 
        nameColor: "text-brand-gold",
        squadColor: "text-brand-gold/60",
        border: "border-brand-gold/30", 
        bg: "bg-brand-gold/5",
        dot: "bg-brand-gold/60",
        xpBg: "bg-brand-gold/10",
        xpText: "text-brand-gold",
        lineColor: "bg-brand-gold/30"
      } 
    },
    { 
      title: "Architect", 
      badge: "Nível Avançado - Formatura", 
      desc: "Habilidade para desenhar arquiteturas completas de growth e marketing.", 
      img: proxyImage("https://leydux.com.br/wp-content/uploads/2026/03/05-1.png"), 
      isAdvanced: true, 
      isArchitect: true,
      squad: { 
        name: "Axis", 
        desc: "Alta performance e liderança", 
        xp: "1000 XP", 
        nameColor: "text-brand-blue",
        squadColor: "text-brand-gold/60",
        border: "border-brand-gold/50", 
        bg: "bg-brand-gold/10",
        dot: "bg-brand-gold/60",
        xpBg: "bg-brand-gold/20",
        xpText: "text-brand-blue",
        lineColor: "bg-brand-gold/50"
      } 
    }
  ];

  return (
    <div className="flex flex-col justify-start h-full max-w-7xl mx-auto w-full px-4 py-4 pt-32">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
        <h2 className="text-4xl md:text-5xl font-serif text-brand-gold mb-2">Sistema de Patentes & Squads</h2>
        <p className="text-brand-blue/70 text-base">Evolução técnica e integração prática no ecossistema Linkar.</p>
      </motion.div>

      <div className="grid grid-cols-5 gap-x-4 gap-y-0 relative">
        {/* Row 1: Patents */}
        {patentes.map((patente, idx) => (
          <div key={`pat-${idx}`} className="flex flex-col h-full">
            <motion.div 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + (idx * 0.1) }}
              className={`flex flex-col items-center text-center p-4 rounded-2xl w-full h-full transition-all duration-300 z-10
                ${patente.isArchitect ? 'bg-white border-2 border-brand-gold shadow-xl shadow-brand-gold/10' : 'bg-white border border-brand-blue/10 shadow-lg'}
              `}
            >
              <div className="w-16 h-16 mb-3 flex items-center justify-center">
                <ProxyImage src={patente.img} alt={patente.title} className="w-full h-full object-contain" referrerPolicy="no-referrer" crossOrigin="anonymous" />
              </div>
              <h3 className={`text-lg font-bold mb-1 ${patente.isArchitect ? 'text-brand-gold' : 'text-brand-blue'}`}>{patente.title}</h3>
              <div className={`px-2 py-0.5 rounded-full text-[9px] font-semibold mb-2 tracking-wide
                ${patente.isAdvanced ? 'bg-brand-gold/10 text-brand-gold' : 'bg-brand-blue/5 text-brand-blue/70'}
              `}>
                {patente.badge}
              </div>
              <p className="text-[10px] leading-tight text-brand-blue/70">
                {patente.desc}
              </p>
            </motion.div>
          </div>
        ))}

        {/* Row 2: Connection Lines */}
        {patentes.map((patente, idx) => (
          <div key={`line-${idx}`} className="h-8 flex justify-center relative">
            {patente.squad && (
              <motion.div 
                initial={{ height: 0 }} animate={{ height: 32 }} transition={{ delay: 0.8 + (idx * 0.1) }}
                className={`w-px ${patente.squad.lineColor}`}
              />
            )}
          </div>
        ))}

        {/* Row 3: Squads */}
        {patentes.map((patente, idx) => (
          <div key={`squad-${idx}`} className="h-full">
            {patente.squad && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 1 + (idx * 0.1) }}
                className={`p-4 rounded-xl border w-full h-full ${patente.squad.border} ${patente.squad.bg} flex flex-col items-center text-center relative shadow-sm`}
              >
                <div className={`flex items-center gap-1.5 mb-1`}>
                  <div className={`w-1.5 h-1.5 rounded-full ${patente.squad.dot} animate-pulse`}></div>
                  <span className={`text-[9px] font-bold uppercase tracking-widest ${patente.squad.squadColor}`}>Squad</span>
                </div>
                <h4 className={`text-xl font-serif font-bold mb-1 ${patente.squad.nameColor}`}>{patente.squad.name}</h4>
                <p className="text-[10px] text-brand-blue/80 mb-2 leading-tight font-medium">{patente.squad.desc}</p>
                <div className={`text-[10px] font-bold px-3 py-0.5 rounded-full border ${patente.squad.border} ${patente.squad.xpBg} ${patente.squad.xpText} shadow-sm mt-auto`}>
                  XP: {patente.squad.xp}
                </div>
              </motion.div>
            )}
          </div>
        ))}
      </div>

      {/* Footer Section */}
      <div className="mt-auto flex flex-col items-center gap-4 pt-8">
        <motion.div 
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.6 }}
          className="bg-brand-blue text-white px-8 py-4 rounded-2xl shadow-xl relative overflow-hidden max-w-3xl"
        >
          <div className="absolute top-0 left-0 w-1.5 h-full bg-brand-gold"></div>
          <p className="text-base md:text-lg font-serif italic text-center">
            "No Linkar, ninguém atua antes de estar preparado — e ninguém evolui sem ser testado."
          </p>
        </motion.div>
      </div>
    </div>
  );
};

const ShapeDesign = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="100" cy="100" r="98" stroke="currentColor" strokeWidth="4" strokeDasharray="10 10"/>
    <path d="M50 100 L150 100 M100 50 L100 150" stroke="currentColor" strokeWidth="2"/>
  </svg>
);

const ShapeMarketing = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="20" y="20" width="160" height="160" stroke="currentColor" strokeWidth="4" transform="rotate(45 100 100)"/>
    <circle cx="100" cy="100" r="40" stroke="currentColor" strokeWidth="2"/>
  </svg>
);

const LOGOS = {
  capa: logoSummit
};

export const Slide11 = () => (
  <div className="absolute -inset-12 md:-inset-20 lg:-inset-24 bg-[#0f172a] flex flex-col items-center justify-center text-center z-10 gap-10 lg:gap-12 px-8 md:px-24 overflow-hidden">
    {/* Grid Background */}
    <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff0a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff0a_1px,transparent_1px)] bg-[size:40px_40px] -z-20"></div>
    
    {/* Elementos visuais de fundo mantendo a identidade da capa */}
    <ShapeDesign className="absolute top-16 left-16 w-[300px] h-[300px] md:w-[400px] md:h-[400px] text-white/5 -z-10" />
    <ShapeMarketing className="absolute bottom-16 right-16 w-[300px] h-[300px] md:w-[500px] md:h-[500px] text-[#b8360e]/5 -z-10" />
    
    {/* Tag Superior */}
    <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="relative z-20">
      <div className="inline-block border border-[#b8360e] rounded-full px-8 py-2">
        <span className="text-sm md:text-base font-bold tracking-[0.2em] text-white uppercase">Evento Oficial</span>
      </div>
    </motion.div>
    
    {/* Logo Linkar Summit */}
    <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 }} className="flex flex-col items-center justify-center w-full mt-4 relative z-20">
      <ProxyImage 
        src={LOGOS.capa} 
        alt="Linkar Summit" 
        className="w-[60%] md:w-[35%] max-w-lg object-contain h-auto" 
        referrerPolicy="no-referrer" 
      />
      <div className="mt-6 bg-[#b8360e] text-white text-sm md:text-base font-bold px-6 py-2 rounded-full tracking-wider shadow-lg">
        29 de Abril
      </div>
    </motion.div>

    {/* Linha divisória */}
    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 64 }} transition={{ delay: 0.4 }} className="w-[1px] h-16 bg-[#b8360e] mt-4 mb-4 relative z-20"></motion.div>

    {/* Textos Solicitados */}
    <div className="flex flex-col items-center max-w-5xl relative z-20">
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="text-lg md:text-2xl text-gray-300 leading-relaxed mb-8 font-light">
        O Linkar Business Summit é o evento de lançamento do ecossistema <strong className="text-[#b8360e] font-bold">Linkar Academy</strong>, concebido como uma ponte entre profissionais e empresários.
      </motion.p>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }} className="text-lg md:text-2xl text-gray-300 leading-relaxed font-light">
        Seu propósito é promover alinhamento, aperfeiçoamento e protagonismo entre esses dois lados, fortalecendo uma nova relação entre quem constrói carreiras e quem constrói negócios.
      </motion.p>
    </div>
  </div>
);

export const Slide12 = () => (
  <div className="flex flex-col items-center justify-center h-full text-center">
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="max-w-4xl flex flex-col items-center"
    >
      <ProxyImage
        src={logoHorizontal}
        alt="Linkar Academy"
        className="h-10 md:h-12 w-auto mb-8"
        referrerPolicy="no-referrer"
        crossOrigin="anonymous"
      />
      <h2 className="text-3xl md:text-4xl font-light text-brand-blue leading-relaxed tracking-wide mb-12">
        Um curso de nível <span className="font-serif text-brand-gold italic text-4xl md:text-5xl mx-1">MBA</span>,
        <br/> com 360 horas,
        <br/> totalmente online e livre.
      </h2>
    </motion.div>
  </div>
);
