import fs from 'fs';

const content = fs.readFileSync('./src/assets/logos.ts', 'utf-8');

const extractBase64 = (name: string) => {
  const regex = new RegExp(`export const ${name} = "data:image/svg\\+xml;base64,([^"]+)"`);
  const match = content.match(regex);
  return match ? match[1] : null;
};

const logoHorizontal = extractBase64('logoHorizontal');
const logoWhite = extractBase64('logoWhite');
const logoSummit = extractBase64('logoSummit');

if (logoHorizontal) fs.writeFileSync('./src/assets/logo-horizontal.svg', Buffer.from(logoHorizontal, 'base64').toString('utf-8'));
if (logoWhite) fs.writeFileSync('./src/assets/logo-white.svg', Buffer.from(logoWhite, 'base64').toString('utf-8'));
if (logoSummit) fs.writeFileSync('./src/assets/logo-summit.svg', Buffer.from(logoSummit, 'base64').toString('utf-8'));

console.log('Done');
